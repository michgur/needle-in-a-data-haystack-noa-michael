Execute the scripts in the following order:
1. `code/demographics_crawler.py` corresponds to part 3.1
2. `code/main.py` corresponds to parts 4.2-5.4
